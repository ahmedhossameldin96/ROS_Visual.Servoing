#!/usr/bin/env python

import rospy
import cv2
import numpy as np
from cv_bridge import CvBridge, CvBridgeError
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image


# this class will be the responsible of the robot movements
class MoveKobuki(object):
    # creating a publisher node and make the robot move
    def __init__(self):
    
        self.cmd_vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.last_cmdvel_command = Twist()
        self._cmdvel_pub_rate = rospy.Rate(10)
        self.shutdown_detected = False

    def move_robot(self, twist_object):
        self.cmd_vel_pub.publish(twist_object)
                                    
    def clean_class(self):
        # Stop Robot
        twist_object = Twist()
        twist_object.angular.z = 0.0
        self.move_robot(twist_object)
        self.shutdown_detected = True

class LineFollower(object):

    def __init__(self):
    
        self.bridge_object = CvBridge()
        self.image_sub = rospy.Subscriber("/camera/rgb/image_raw",Image,self.camera_callback)
        self.movekobuki_object = MoveKobuki()

    def camera_callback(self,data):
        
        try:
            cv_image = self.bridge_object.imgmsg_to_cv2(data, desired_encoding="bgr8")
        except CvBridgeError as e:
            print(e)
            

       # we will get the dimensions of the image and clop it by pixels numbers     
        height, width, channels = cv_image.shape
        crop_img = cv_image[260:440][1:width]
        # hsv will be the cropped converted image colored
        hsv = cv2.cvtColor(crop_img, cv2.COLOR_BGR2HSV)

        # we will write the limits of the yellow color
        yel_min  = np.array([20,200,200])
        yel_max = np.array([40,255,255])

        # the threshold the HSV image to get only yellow colors
        mask = cv2.inRange(hsv, yel_min , yel_max )
        
        # calculating the centroid of the blob of binary image using ImageMoments
        m = cv2.moments(mask, False)
        try:
            cx, cy = m['m10']/m['m00'], m['m01']/m['m00']
        except ZeroDivisionError:
            cy, cx = height/2, width/2
        
        
        # Bitwise-AND ( mask and cropped original image)
        res = cv2.bitwise_and(crop_img,crop_img, mask= mask)
        
        # Draw a red circle in the centroid of the resultut image
        cv2.circle(res,(int(cx), int(cy)), 10,(0,0,255),-1)
        
        # showing all results
        cv2.imshow("Original", cv_image)
        cv2.imshow("HSV", hsv)
        cv2.imshow("MASK", mask)
        cv2.imshow("RES", res)
        
        cv2.waitKey(1)
        
       # if the robot didn't detect yellow color cx =  width / 2 and error_x =0
        error_x = cx - width / 2;
        twist_object = Twist();
        # if the robot did't detect yellow color will turn arround
        if error_x == 0 :
            twist_object.angular.z= 0.2
          # will make the robot move linear.x if it detect any yellow color only 
        else : 
            twist_object.linear.x = 0.2;
            twist_object.angular.z = -error_x / 100;
            rospy.loginfo("ANGULAR VALUE SENT===>"+str(twist_object.angular.z))
            # Make it start turning with the linear movement
        self.movekobuki_object.move_robot(twist_object)
        
    def clean_up(self):
        self.movekobuki_object.clean_class()
        cv2.destroyAllWindows()
        
        

def main():
    rospy.init_node('line_following_node', anonymous=True)
    
    movekobuki_object = MoveKobuki()
    line_follower_object = LineFollower()
   
    rate = rospy.Rate(5)
    ctrl_c = False
    # the shutting down of the operation 
    def shutdownhook():
        line_follower_object.clean_up()
        movekobuki_object.clean_class()
        rospy.loginfo("shutdown time!")
        ctrl_c = True
    
    rospy.on_shutdown(shutdownhook)
    
    while not ctrl_c:
        rate.sleep()
        
    
    
if __name__ == '__main__':
    main()