#!/usr/bin/env python

import sys
import rospy
import cv2
import numpy as np

bgr_yel =  np.uint8([[[0, 255,255]]])
hsv_yel = cv2.cvtColor(bgr_yel,cv2.COLOR_BGR2HSV)
print (hsv_yel)
cv2.destroyAllWindows()